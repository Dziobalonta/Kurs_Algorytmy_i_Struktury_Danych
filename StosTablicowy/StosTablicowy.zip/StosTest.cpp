#include <iostream>
#include "StosTablicowy.h"

using std::cout;
using std::endl;

int main()
{
    Stos pile;
    printf("%s\n",pile.Empty() ? "true" : "false");

    pile.Push(5);
    pile.Print();

    cout << pile.TopElem() << endl;

    printf("%s\n",pile.Empty() ? "true" : "false");

    pile.Pop();
    pile.Print();

    printf("%s\n",pile.Empty() ? "true" : "false");

    pile.Push(2);
    pile.Print();

    pile.Push(3);
    pile.Print();

    cout << pile.TopElem() << endl;

    pile.Makenull();
    pile.Print();

    printf("%s\n",pile.Empty() ? "true" : "false");
    return 0;
}